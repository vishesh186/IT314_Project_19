from django.shortcuts import render, redirect
from .models import *
from django.utils.text import slugify
from django.forms.models import model_to_dict


# Create your views here.

def Home(request):
    return render(request, 'home.html')


def Landing(request):
    return render(request, 'landing.html')


def Login(request):
    return render(request, 'login.html')


def CreateProject(request):
    projectManagers = Employee.objects.filter(role='PM')
    if request.method == "POST":
        project = Project(
            projectID=slugify(request.POST['title']),
            title=request.POST['title'],
            client=request.POST['client'],
            description=request.POST['description'],
            budget=request.POST['budget'],
            deadline=request.POST['deadline'],
            manager=model_to_dict(projectManagers.get(employeeID=request.POST['manager']))  
        )
        project.save()
    return render(request, 'createProject.html', {'managers':projectManagers})


def CreateTeam(request):
    return render(request, 'createTeam.html')


def CreateTask(request):
    return render(request, 'createTask.html')


def SubmitReport(request):
    return render(request, 'submitReport.html')


def ViewProjects(request):

    return render(request, 'viewProjects.html')


def ProjectDashboard(request):
    return render(request, 'projectDashboard.html')


def ViewTeams(request):
    return render(request, 'viewTeams.html')


def TeamDashboard(request):
    return render(request, 'teamDashboard.html')


def Resources(request):
    return render(request, 'viewResources.html')


def RequestResource(request):
    return render(request, 'requestResource.html')


def ManageResources(request):
    return render(request, 'manageResources.html')
