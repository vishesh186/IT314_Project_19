from django.apps import AppConfig


class ProjectmanagementsystemappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ProjectManagementSystemApp'
